from flask import Flask, render_template, request, send_file
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.utils import simpleSplit
import io

app = Flask(__name__)

# ─── Number to Indian Words ───────────────────────────────────────────────────
_ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight',
         'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen',
         'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen']
_TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty',
         'Sixty', 'Seventy', 'Eighty', 'Ninety']

def _n2w(n):
    if n == 0: return ''
    if n < 20: return _ONES[n]
    if n < 100:
        return (_TENS[n // 10] + (' ' + _n2w(n % 10) if n % 10 else '')).strip()
    if n < 1000:
        return (_ONES[n // 100] + ' Hundred' + (' ' + _n2w(n % 100) if n % 100 else '')).strip()
    if n < 100_000:
        return (_n2w(n // 1000) + ' Thousand' + (' ' + _n2w(n % 1000) if n % 1000 else '')).strip()
    if n < 10_000_000:
        return (_n2w(n // 100_000) + ' Lakh' + (' ' + _n2w(n % 100_000) if n % 100_000 else '')).strip()
    return (_n2w(n // 10_000_000) + ' Crore' + (' ' + _n2w(n % 10_000_000) if n % 10_000_000 else '')).strip()

def amount_to_words(amount):
    n = round(float(amount))
    return f'Rupees {_n2w(n) or "Zero"} Only (Rs. {n:,.2f})'


# ─── PDF Generator ────────────────────────────────────────────────────────────
def generate_invoice_pdf(data):
    buf = io.BytesIO()
    W, H = A4   # 595.27 × 841.89 pts

    # Palette
    NAVY   = colors.Color(0.067, 0.094, 0.153)
    AMBER  = colors.Color(0.957, 0.620, 0.043)
    LGRAY  = colors.Color(0.950, 0.950, 0.950)
    MGRAY  = colors.Color(0.720, 0.720, 0.720)
    DGRAY  = colors.Color(0.400, 0.400, 0.400)
    BLACK  = colors.Color(0.100, 0.100, 0.100)
    WHITE  = colors.white
    ALTROW = colors.Color(0.960, 0.960, 0.970)

    ML = 35; MR = 35; PW = W - ML - MR

    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle(f"Invoice {data['invoice_no']}")

    # ── HEADER BAND ──────────────────────────────────────────────────────────
    HDR_H = 65
    c.setFillColor(NAVY)
    c.rect(0, H - HDR_H, W, HDR_H, fill=1, stroke=0)

    c.setFillColor(colors.Color(0.55, 0.55, 0.55))
    c.setFont('Helvetica', 6.5)
    c.drawRightString(W - MR, H - 10, 'Original for Recipient')

    c.setFillColor(WHITE)
    c.setFont('Helvetica-Bold', 20)
    c.drawString(ML, H - 32, data['company_name'])

    c.setFillColor(colors.Color(0.72, 0.72, 0.72))
    c.setFont('Helvetica', 7.5)
    c.drawString(ML, H - 46, data['tagline'])

    # INVOICE badge
    BW, BH, BX, BY = 78, 22, W - MR - 78, H - 57
    c.setFillColor(AMBER)
    c.roundRect(BX, BY, BW, BH, 5, fill=1, stroke=0)
    c.setFillColor(NAVY)
    c.setFont('Helvetica-Bold', 11)
    c.drawCentredString(BX + BW / 2, BY + 6, 'INVOICE')

    y = H - HDR_H - 12

    # ── FROM | INVOICE DETAILS (two columns) ─────────────────────────────────
    half = (PW - 10) / 2
    RX = ML + half + 10

    def sec_hdr(cx, label, w):
        c.setFillColor(NAVY); c.setFont('Helvetica-Bold', 7.5)
        c.drawString(cx, y, label)
        c.setFillColor(MGRAY)
        c.rect(cx, y - 4, w, 0.5, fill=1, stroke=0)

    sec_hdr(ML, 'FROM', half)
    sec_hdr(RX, 'INVOICE DETAILS', half)

    fy = y - 16
    c.setFont('Helvetica-Bold', 9); c.setFillColor(BLACK)
    c.drawString(ML, fy, data['from_name']); fy -= 12
    for line in [data['from_address'],
                 f"Ph: {data['from_phone']}", data['from_email'], data['from_website']]:
        c.setFont('Helvetica', 8); c.setFillColor(DGRAY)
        c.drawString(ML, fy, line); fy -= 10

    dy = y - 16
    for lbl, val in [('Invoice No.:', data['invoice_no']),
                     ('Date:',         data['invoice_date']),
                     ('Due Date:',     data['due_date']),
                     ('Type:',         data['invoice_type']),
                     ('Place of Supply:', data['place_of_supply'])]:
        c.setFont('Helvetica', 8);       c.setFillColor(DGRAY);  c.drawString(RX, dy, lbl)
        c.setFont('Helvetica-Bold', 8);  c.setFillColor(BLACK);  c.drawString(RX + 95, dy, val)
        dy -= 11

    y = min(fy, dy) - 10
    c.setFillColor(MGRAY); c.rect(ML, y + 5, PW, 0.5, fill=1, stroke=0); y -= 5

    # ── BILL TO ──────────────────────────────────────────────────────────────
    c.setFillColor(NAVY); c.setFont('Helvetica-Bold', 7.5); c.drawString(ML, y, 'BILL TO')
    c.setFillColor(MGRAY); c.rect(ML, y - 4, PW, 0.5, fill=1, stroke=0); y -= 16

    c.setFont('Helvetica-Bold', 9); c.setFillColor(BLACK)
    c.drawString(ML, y, data['bill_to_name']); y -= 12
    c.setFont('Helvetica-Bold', 8.5)
    c.drawString(ML, y, data['bill_to_company']); y -= 11
    c.setFont('Helvetica', 8); c.setFillColor(DGRAY)
    c.drawString(ML, y, data['bill_to_address']); y -= 10
    c.drawString(ML, y, f"Ph: {data['bill_to_phone']}"); y -= 13

    # Scope bar
    scope_lines = simpleSplit(f"SCOPE: {data['scope']}", 'Helvetica-Bold', 7.5, PW - 10)
    scope_bar_h = len(scope_lines) * 10 + 6
    c.setFillColor(LGRAY); c.rect(ML, y - scope_bar_h + 12, PW, scope_bar_h, fill=1, stroke=0)
    c.setFillColor(BLACK); c.setFont('Helvetica-Bold', 7.5)
    sy = y + 3
    for sl in scope_lines:
        c.drawString(ML + 5, sy, sl); sy -= 10
    y = sy - 8

    # ── ITEMS TABLE ──────────────────────────────────────────────────────────
    C_NUM, C_SAC, C_UP, C_LT = 22, 60, 78, 78
    C_DESC = PW - C_NUM - C_SAC - C_UP - C_LT
    cx = [ML, ML + C_NUM, ML + C_NUM + C_DESC,
          ML + C_NUM + C_DESC + C_SAC, ML + C_NUM + C_DESC + C_SAC + C_UP]

    c.setFillColor(NAVY); c.rect(ML, y - 3, PW, 18, fill=1, stroke=0)
    c.setFillColor(WHITE); c.setFont('Helvetica-Bold', 7.5)
    for txt, xi, wi, align in [('#', cx[0], C_NUM, 'c'),
                                 ('DESCRIPTION', cx[1], C_DESC, 'l'),
                                 ('SAC', cx[2], C_SAC, 'c'),
                                 ('UNIT PRICE', cx[3], C_UP, 'r'),
                                 ('LINE TOTAL', cx[4], C_LT, 'r')]:
        ty = y + 2
        if align == 'c': c.drawCentredString(xi + wi / 2, ty, txt)
        elif align == 'r': c.drawRightString(xi + wi - 4, ty, txt)
        else: c.drawString(xi + 4, ty, txt)
    y -= 20

    items = data.get('line_items', [])
    for idx, item in enumerate(items):
        desc_text = item.get('description', '')
        nat_lines = [l for l in desc_text.split('\n')]

        # Calculate total rendered lines for row height
        all_rendered = []
        for i, nl in enumerate(nat_lines):
            if not nl.strip(): continue
            font = 'Helvetica-Bold' if i == 0 else 'Helvetica'
            fsize = 8 if i == 0 else 7.5
            subs = simpleSplit(nl, font, fsize, C_DESC - 8) or ['']
            all_rendered.extend([(s, i == 0) for s in subs])

        row_h = max(24, len(all_rendered) * 10 + 10)

        if idx % 2 == 0:
            c.setFillColor(ALTROW)
            c.rect(ML, y - row_h + 12, PW, row_h, fill=1, stroke=0)

        c.setFillColor(BLACK); c.setFont('Helvetica-Bold', 8)
        c.drawCentredString(cx[0] + C_NUM / 2, y, str(idx + 1))

        desc_y = y
        for (txt, is_title) in all_rendered:
            if is_title:
                c.setFont('Helvetica-Bold', 8); c.setFillColor(BLACK)
            else:
                c.setFont('Helvetica', 7.5); c.setFillColor(DGRAY)
            c.drawString(cx[1] + 4, desc_y, txt); desc_y -= 10

        try: up = float(item.get('unit_price', 0))
        except: up = 0.0

        c.setFont('Helvetica', 8); c.setFillColor(DGRAY)
        c.drawCentredString(cx[2] + C_SAC / 2, y, str(item.get('sac', '')))

        c.setFont('Helvetica', 8); c.setFillColor(BLACK)
        c.drawRightString(cx[3] + C_UP - 4, y, f"Rs. {up:,.2f}")

        c.setFont('Helvetica-Bold', 8)
        c.drawRightString(cx[4] + C_LT - 4, y, f"Rs. {up:,.2f}")

        y -= row_h
        c.setFillColor(MGRAY); c.rect(ML, y + 8, PW, 0.3, fill=1, stroke=0)

    # ── SUBTOTALS BLOCK (right-aligned) ──────────────────────────────────────
    y -= 8
    grand = sum(float(it.get('unit_price', 0)) for it in items)
    sub_x = ML + PW * 0.48
    sub_w = PW * 0.52

    for item in items:
        up = float(item.get('unit_price', 0))
        label = item.get('description', '').split('\n')[0]
        if len(label) > 44: label = label[:44] + '…'
        c.setFont('Helvetica', 8); c.setFillColor(DGRAY)
        c.drawString(sub_x + 4, y, label)
        c.setFillColor(BLACK)
        c.drawRightString(sub_x + sub_w - 2, y, f"Rs. {up:,.2f}")
        y -= 12

    y -= 4
    c.setFillColor(NAVY); c.rect(sub_x, y - 4, sub_w, 20, fill=1, stroke=0)
    c.setFillColor(WHITE); c.setFont('Helvetica-Bold', 9)
    c.drawString(sub_x + 6, y + 3, 'TOTAL PAYABLE')
    c.drawRightString(sub_x + sub_w - 4, y + 3, f"Rs. {grand:,.2f}")
    y -= 28

    # Amount in words
    c.setFillColor(LGRAY); c.rect(ML, y - 3, PW, 16, fill=1, stroke=0)
    c.setFillColor(BLACK); c.setFont('Helvetica-Bold', 8)
    c.drawString(ML + 5, y + 4, f"Amount in Words:  {amount_to_words(grand)}")
    y -= 24

    # ── PAYMENT SUMMARY | PAYMENT DETAILS ────────────────────────────────────
    pw_col = (PW - 15) / 2
    pdx = ML + pw_col + 15
    ps_y = y

    c.setFillColor(NAVY); c.setFont('Helvetica-Bold', 7.5)
    c.drawString(ML, y, 'PAYMENT SUMMARY')
    c.setFillColor(MGRAY); c.rect(ML, y - 4, pw_col, 0.5, fill=1, stroke=0)
    psy = y - 15
    for item in items:
        up = float(item.get('unit_price', 0))
        lbl = item.get('description', '').split('\n')[0]
        if len(lbl) > 30: lbl = lbl[:30] + '…'
        c.setFont('Helvetica', 8); c.setFillColor(DGRAY); c.drawString(ML, psy, lbl)
        c.setFont('Helvetica-Bold', 8); c.setFillColor(BLACK)
        c.drawRightString(ML + pw_col, psy, f"Rs. {up:,.2f}"); psy -= 11
    psy -= 4
    c.setFillColor(MGRAY); c.rect(ML, psy, pw_col, 0.5, fill=1, stroke=0); psy -= 12
    c.setFont('Helvetica-Bold', 9); c.setFillColor(BLACK)
    c.drawString(ML, psy, 'TOTAL PAYABLE:')
    c.drawRightString(ML + pw_col, psy, f"Rs. {grand:,.2f}")

    c.setFillColor(NAVY); c.setFont('Helvetica-Bold', 7.5)
    c.drawString(pdx, ps_y, 'PAYMENT DETAILS')
    c.setFillColor(MGRAY); c.rect(pdx, ps_y - 4, pw_col, 0.5, fill=1, stroke=0)
    pdy = ps_y - 15
    for field in [f"{data.get('bank_name','')} | A/C: {data.get('account_no','')}",
                  f"A/C Name: {data.get('account_name','')}",
                  f"IFSC: {data.get('ifsc','')}",
                  f"UPI ID: {data.get('upi_id','')}",
                  f"Reference: Mention Invoice No. {data['invoice_no']} when making payment"]:
        c.setFont('Helvetica', 8); c.setFillColor(BLACK)
        c.drawString(pdx, pdy, field); pdy -= 11

    y = min(psy, pdy) - 18

    # ── TERMS & CONDITIONS ────────────────────────────────────────────────────
    c.setFillColor(NAVY); c.setFont('Helvetica-Bold', 7.5)
    c.drawString(ML, y, 'TERMS & CONDITIONS')
    c.setFillColor(MGRAY); c.rect(ML, y - 4, PW, 0.5, fill=1, stroke=0)
    y -= 15
    for i, term in enumerate(data.get('terms', []), 1):
        for tl in simpleSplit(f"{i}. {term}", 'Helvetica', 7.5, PW - 8):
            c.setFont('Helvetica', 7.5); c.setFillColor(BLACK)
            c.drawString(ML, y, tl); y -= 10
        y -= 2

    # Signatory
    y -= 8
    c.setFont('Helvetica', 8); c.setFillColor(DGRAY)
    c.drawRightString(W - MR, y, 'Authorized Signatory'); y -= 11
    c.setFont('Helvetica-Bold', 8); c.setFillColor(BLACK)
    c.drawRightString(W - MR, y, f"For {data['company_name']}"); y -= 11
    c.drawRightString(W - MR, y, data.get('signatory', 'Chirag | Founder & Director'))

    # Thank you
    y -= 22
    c.setFillColor(AMBER); c.setFont('Helvetica-Bold', 11)
    c.drawCentredString(W / 2, y, 'Thank You For Your Business!'); y -= 13
    c.setFillColor(DGRAY); c.setFont('Helvetica', 8)
    c.drawCentredString(W / 2, y, 'We look forward to a fruitful long-term partnership.')

    # ── FOOTER BAND ──────────────────────────────────────────────────────────
    FH = 32
    c.setFillColor(NAVY); c.rect(0, 0, W, FH, fill=1, stroke=0)
    c.setFillColor(WHITE); c.setFont('Helvetica', 7)
    c.drawCentredString(W / 2, FH - 10,
        f"{data['from_website']}  |  {data['from_email']}  |  {data['from_phone']}  |  Jaipur, Rajasthan")
    c.setFillColor(colors.Color(0.65, 0.65, 0.65)); c.setFont('Helvetica', 6.5)
    c.drawCentredString(W / 2, FH - 21, data['tagline'])
    c.setFillColor(colors.Color(0.45, 0.45, 0.45)); c.setFont('Helvetica', 5.5)
    c.drawCentredString(W / 2, 4,
        '* Subject to Jaipur, Rajasthan jurisdiction.   * Computer-generated invoice.')

    c.save()
    buf.seek(0)
    return buf


# ─── Default Data (pre-filled from PP96002) ──────────────────────────────────
DEFAULT = {
    'company_name':    'PROTON PUBLISHERS',
    'tagline':         'Digital Marketing | AI Automation | Web Design | Social Media',
    'from_name':       'Proton Publishers',
    'from_address':    'D52, Jaipur, Rajasthan - 302001',
    'from_phone':      '+91 96539 46780',
    'from_email':      'hello.protonpublishers@gmail.com',
    'from_website':    'www.protonpublishers.in',
    'invoice_no':      'PP96002',
    'invoice_date':    '10-06-2026',
    'due_date':        '10-07-2026',
    'invoice_type':    'Token + Project Delivery',
    'place_of_supply': 'Rajasthan (08)',
    'bill_to_name':    'Anjali Randhelia | Director',
    'bill_to_company': 'BISI WORLD INTERNATIONAL',
    'bill_to_address': '1270, Acharyon Ka Rasta, Kishanpole Bazar, Jaipur - 302020',
    'bill_to_phone':   '+91 9509710745',
    'scope':           'Social Media | Facebook Ads | Google Ads | GMB | Video Shoot & Edit | Content Creation | Lead Gen | B2B Listing',
    'line_items': [
        {
            'description': 'Digital Marketing Retainer — Token / Advance Payment\nIncludes: Video Shoot & Edit, Social Media Management,\nFacebook Ads, GMB, Content Creation, Animation Video',
            'sac': '998361',
            'unit_price': '5000',
        },
        {
            'description': 'ProConvert Suite — PDF to Excel Converter (x 2 Modules)\nModule 1 — ProConvert Lite : Single PDF to Excel\nModule 2 — ProConvert Pro : Bulk PDF to Excel',
            'sac': '998313',
            'unit_price': '8000',
        },
    ],
    'bank_name':    'IndusInd Bank, Jaipur',
    'account_no':   '159653946780',
    'account_name': 'Sheer Sagar Sharma',
    'ifsc':         'IINDB0001925',
    'upi_id':       '9653946780@ybl',
    'signatory':    'Chirag | Founder & Director',
    'terms': [
        'This invoice covers Token/Advance for Digital Marketing Retainer and full delivery payment for ProConvert Suite.',
        'Balance of Rs. 15,000 for Digital Marketing Retainer is due within 30 days of project commencement.',
        'For support & queries: hello.protonpublishers@gmail.com | +91 96539 46780',
    ],
}


# ─── Routes ──────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html', data=DEFAULT)


@app.route('/generate', methods=['POST'])
def generate():
    f = request.form

    # Parse items
    descs  = f.getlist('item_description[]')
    sacs   = f.getlist('item_sac[]')
    prices = f.getlist('item_unit_price[]')
    items  = []
    for desc, sac, price in zip(descs, sacs, prices):
        if desc.strip():
            items.append({'description': desc.strip(),
                          'sac':         sac.strip(),
                          'unit_price':  price.strip() or '0'})

    terms = [t.strip() for t in f.getlist('term[]') if t.strip()]

    data = {
        'company_name':    f.get('company_name', ''),
        'tagline':         f.get('tagline', ''),
        'from_name':       f.get('from_name', ''),
        'from_address':    f.get('from_address', ''),
        'from_phone':      f.get('from_phone', ''),
        'from_email':      f.get('from_email', ''),
        'from_website':    f.get('from_website', ''),
        'invoice_no':      f.get('invoice_no', ''),
        'invoice_date':    f.get('invoice_date', ''),
        'due_date':        f.get('due_date', ''),
        'invoice_type':    f.get('invoice_type', ''),
        'place_of_supply': f.get('place_of_supply', ''),
        'bill_to_name':    f.get('bill_to_name', ''),
        'bill_to_company': f.get('bill_to_company', ''),
        'bill_to_address': f.get('bill_to_address', ''),
        'bill_to_phone':   f.get('bill_to_phone', ''),
        'scope':           f.get('scope', ''),
        'line_items':      items,
        'bank_name':       f.get('bank_name', ''),
        'account_no':      f.get('account_no', ''),
        'account_name':    f.get('account_name', ''),
        'ifsc':            f.get('ifsc', ''),
        'upi_id':          f.get('upi_id', ''),
        'signatory':       f.get('signatory', ''),
        'terms':           terms,
    }

    pdf = generate_invoice_pdf(data)
    fname = f"Invoice_{data['invoice_no'].replace('/', '-')}.pdf"
    return send_file(pdf, as_attachment=True,
                     download_name=fname, mimetype='application/pdf')


if __name__ == '__main__':
    app.run(debug=True, port=5050)
